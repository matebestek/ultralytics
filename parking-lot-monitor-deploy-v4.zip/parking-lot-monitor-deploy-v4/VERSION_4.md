# Parking Lot Monitor — Deployment v4

Created: 2025-12-12

Changes in v4:
- New deployment package version v4 (copy of v3 contents)
- Included `VERSION_4.md` for packaging/version tracking

Package includes `parking_lot_monitor.py`, docs, start scripts, and `yolo11n.pt`.
